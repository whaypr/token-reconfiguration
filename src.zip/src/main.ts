import { createPFairnessApp } from "./core";
import { scenarios } from "./scenarios";
import type { LayoutMode, PFairnessApp } from "./types";

function bootstrap(): void {
    const scenarioSelect = document.getElementById("scenarioSelect") as HTMLSelectElement;
    const layoutSelect = document.getElementById("layoutSelect") as HTMLSelectElement;
    const repulsionToggle = document.getElementById("repulsionToggle") as HTMLInputElement;
    const scenarioDescription = document.getElementById("scenarioDescription") as HTMLElement;

    if (!scenarioSelect || !layoutSelect || !repulsionToggle || !scenarioDescription || scenarios.length === 0) {
        window.setTimeout(bootstrap, 0);
        return;
    }

    let currentApp: PFairnessApp | null = null;

    function applyControlsToApp(): void {
        if (!currentApp) {
            return;
        }

        currentApp.applyLayout(layoutSelect.value as LayoutMode);
        currentApp.setRepulsionEnabled(repulsionToggle.checked);
    }

    function renderScenarioOptions(): void {
        scenarioSelect.innerHTML = "";

        scenarios.forEach((scenario, index) => {
            const option = document.createElement("option");
            option.value = String(index);
            option.textContent = scenario.name;
            scenarioSelect.appendChild(option);
        });
    }

    function loadScenario(index: number): void {
        const scenario = scenarios[index] || scenarios[0];

        if (currentApp) {
            currentApp.destroy();
        }

        scenarioDescription.textContent = scenario.description;
        currentApp = createPFairnessApp({
            svgSelector: "svg",
            pInputSelector: "#pValue",
            statusSelector: "#status",
            nodes: scenario.nodes,
            links: scenario.links,
            tokens: scenario.tokens,
            initialP: scenario.initialP,
        });

        applyControlsToApp();
    }

    renderScenarioOptions();

    scenarioSelect.addEventListener("change", event => {
        const target = event.target as HTMLSelectElement;
        loadScenario(Number.parseInt(target.value, 10));
    });

    layoutSelect.addEventListener("change", () => {
        applyControlsToApp();
    });

    repulsionToggle.addEventListener("change", () => {
        if (currentApp) {
            currentApp.setRepulsionEnabled(repulsionToggle.checked);
        }
    });

    scenarioSelect.value = "0";
    layoutSelect.value = "circular";
    repulsionToggle.checked = false;
    loadScenario(0);
}

if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", bootstrap, { once: true });
} else {
    bootstrap();
}