import * as d3 from "d3";
import type { D3DragEvent } from "d3-drag";
import type { Selection } from "d3-selection";
import type { Simulation, SimulationNodeDatum } from "d3-force";
import type { ZoomTransform } from "d3-zoom";
import type { GraphNode, GraphToken, NodeId } from "./types";

type ForceNodeDatum = GraphNode & SimulationNodeDatum;

type EdgeDragState = {
    source: ForceNodeDatum;
    x1: number;
    y1: number;
    x2: number;
    y2: number;
} | null;

type SelectionBoxState = {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
} | null;

type SelectionDragMode = "move" | "rotate";

type SelectionDragState = {
    mode: SelectionDragMode;
    selectedNodeIds: NodeId[];
    startPointer: { x: number; y: number };
    centerX: number;
    centerY: number;
    startPositions: Map<NodeId, { x: number; y: number }>;
} | null;

interface GraphInteractionContext {
    svg: Selection<SVGSVGElement, unknown, null, undefined>;
    backgroundNode: SVGRectElement;
    edgePreview: Selection<SVGLineElement, unknown, null, undefined>;
    selectionPreview: Selection<SVGRectElement, unknown, null, undefined>;
    simulation: Simulation<ForceNodeDatum, undefined>;
    getNodeById: (nodeId: NodeId) => ForceNodeDatum | null;
    getSelectedNodeIds: () => NodeId[];
    isNodeSelected: (nodeId: NodeId) => boolean;
    selectNodesInRectangle: (x1: number, y1: number, x2: number, y2: number) => void;
    clearNodeSelection: () => void;
    positionGraphElements: () => void;
    setStatus: (message: string) => void;
    refreshGraphAfterMutation: (message?: string) => void;
    addNodeAtPoint: (x: number, y: number) => GraphNode;
    addEdge: (sourceNodeId: NodeId, targetNodeId: NodeId) => boolean;
    removeEdge: (sourceNodeId: NodeId, targetNodeId: NodeId) => boolean;
    removeNode: (nodeId: NodeId) => boolean;
    getNodeAtPoint: (x: number, y: number, ignoredNodeId?: NodeId | null) => GraphNode | null;
    currentTransform: () => ZoomTransform;
    isRepulsionEnabled: () => boolean;
}

export interface GraphInteractionController {
    nodeDrag: d3.DragBehavior<SVGCircleElement, ForceNodeDatum, ForceNodeDatum>;
    tokenDrag: d3.DragBehavior<SVGCircleElement, GraphToken, ForceNodeDatum>;
    handleNodeMouseDown(event: MouseEvent, nodeData: GraphNode): void;
    handleBackgroundMouseDown(event: MouseEvent): void;
    stopEdgeDrag(): void;
    destroy(): void;
}

function toGraphPoint(
    svg: Selection<SVGSVGElement, unknown, null, undefined>,
    currentTransform: () => ZoomTransform,
    event: MouseEvent | PointerEvent | D3DragEvent<SVGCircleElement, unknown, ForceNodeDatum>,
): [number, number] {
    const [x, y] = d3.pointer(event, svg.node());
    return currentTransform().invert([x, y]);
}

function snapshotSelectedNodePositions(context: GraphInteractionContext, selectedNodeIds: NodeId[]): Map<NodeId, { x: number; y: number }> {
    const positions = new Map<NodeId, { x: number; y: number }>();

    selectedNodeIds.forEach(nodeId => {
        const nodeData = context.getNodeById(nodeId);
        if (nodeData) {
            positions.set(nodeId, { x: nodeData.x, y: nodeData.y });
        }
    });

    return positions;
}

function computeSelectionCenter(positions: Map<NodeId, { x: number; y: number }>): { x: number; y: number } | null {
    const values = [...positions.values()];

    if (values.length === 0) {
        return null;
    }

    const sum = values.reduce((accumulator, position) => ({
        x: accumulator.x + position.x,
        y: accumulator.y + position.y,
    }), { x: 0, y: 0 });

    return {
        x: sum.x / values.length,
        y: sum.y / values.length,
    };
}

export function createGraphInteractions(context: GraphInteractionContext): GraphInteractionController {
    let edgeDragState: EdgeDragState = null;
    let selectionBoxState: SelectionBoxState = null;
    let selectionDragState: SelectionDragState = null;

    function renderSelectionBox(): void {
        if (!selectionBoxState) {
            context.selectionPreview.style("display", "none");
            return;
        }

        const x = Math.min(selectionBoxState.x1, selectionBoxState.x2);
        const y = Math.min(selectionBoxState.y1, selectionBoxState.y2);
        const width = Math.abs(selectionBoxState.x2 - selectionBoxState.x1);
        const height = Math.abs(selectionBoxState.y2 - selectionBoxState.y1);

        context.selectionPreview
            .style("display", null)
            .attr("x", x)
            .attr("y", y)
            .attr("width", width)
            .attr("height", height);
    }

    function startSelectionBox(nodeX: number, nodeY: number): void {
        selectionBoxState = { x1: nodeX, y1: nodeY, x2: nodeX, y2: nodeY };
        renderSelectionBox();
        window.addEventListener("mousemove", handleWindowMouseMove);
        window.addEventListener("mouseup", handleWindowMouseUp);
    }

    function stopSelectionBox(): void {
        if (!selectionBoxState) {
            return;
        }

        selectionBoxState = null;
        context.selectionPreview.style("display", "none");
        window.removeEventListener("mousemove", handleWindowMouseMove);
        window.removeEventListener("mouseup", handleWindowMouseUp);
    }

    function startEdgeDrag(nodeData: ForceNodeDatum): void {
        const [x, y] = [nodeData.x, nodeData.y];
        edgeDragState = {
            source: nodeData,
            x1: x,
            y1: y,
            x2: x,
            y2: y,
        };

        context.edgePreview
            .style("display", null)
            .attr("x1", x)
            .attr("y1", y)
            .attr("x2", x)
            .attr("y2", y);

        window.addEventListener("mousemove", handleWindowMouseMove);
        window.addEventListener("mouseup", handleWindowMouseUp);
    }

    function stopEdgeDrag(): void {
        if (!edgeDragState) {
            return;
        }

        edgeDragState = null;
        context.edgePreview.style("display", "none");
        window.removeEventListener("mousemove", handleWindowMouseMove);
        window.removeEventListener("mouseup", handleWindowMouseUp);
    }

    function updateSelectionDrag(pointerX: number, pointerY: number): void {
        if (!selectionDragState) {
            return;
        }

        const { mode, startPointer, centerX, centerY, selectedNodeIds, startPositions } = selectionDragState;

        if (mode === "move") {
            const dx = pointerX - startPointer.x;
            const dy = pointerY - startPointer.y;

            selectedNodeIds.forEach(nodeId => {
                const startPosition = startPositions.get(nodeId);
                const nodeData = context.getNodeById(nodeId);

                if (!startPosition || !nodeData) {
                    return;
                }

                const nextX = startPosition.x + dx;
                const nextY = startPosition.y + dy;
                nodeData.x = nextX;
                nodeData.y = nextY;
                nodeData.anchorX = nextX;
                nodeData.anchorY = nextY;
                nodeData.fx = nextX;
                nodeData.fy = nextY;
            });
        } else {
            const startAngle = Math.atan2(startPointer.y - centerY, startPointer.x - centerX);
            const currentAngle = Math.atan2(pointerY - centerY, pointerX - centerX);
            const rotation = currentAngle - startAngle;
            const cosine = Math.cos(rotation);
            const sine = Math.sin(rotation);

            selectedNodeIds.forEach(nodeId => {
                const startPosition = startPositions.get(nodeId);
                const nodeData = context.getNodeById(nodeId);

                if (!startPosition || !nodeData) {
                    return;
                }

                const relativeX = startPosition.x - centerX;
                const relativeY = startPosition.y - centerY;
                const nextX = centerX + relativeX * cosine - relativeY * sine;
                const nextY = centerY + relativeX * sine + relativeY * cosine;
                nodeData.x = nextX;
                nodeData.y = nextY;
                nodeData.anchorX = nextX;
                nodeData.anchorY = nextY;
                nodeData.fx = nextX;
                nodeData.fy = nextY;
            });
        }

        context.positionGraphElements();
    }

    function finishSelectionDrag(): void {
        if (!selectionDragState) {
            return;
        }

        if (context.isRepulsionEnabled()) {
            selectionDragState.selectedNodeIds.forEach(nodeId => {
                const nodeData = context.getNodeById(nodeId);
                if (nodeData) {
                    nodeData.fx = undefined;
                    nodeData.fy = undefined;
                }
            });
        }

        selectionDragState = null;
        context.positionGraphElements();
    }

    function beginSelectionDrag(mode: SelectionDragMode, pointerX: number, pointerY: number): void {
        const selectedNodeIds = context.getSelectedNodeIds();
        const positions = snapshotSelectedNodePositions(context, selectedNodeIds);
        const center = computeSelectionCenter(positions);

        if (!center) {
            return;
        }

        selectionDragState = {
            mode,
            selectedNodeIds,
            startPointer: { x: pointerX, y: pointerY },
            centerX: center.x,
            centerY: center.y,
            startPositions: positions,
        };

        if (!context.isRepulsionEnabled()) {
            selectedNodeIds.forEach(nodeId => {
                const node = context.getNodeById(nodeId);
                if (node) {
                    node.fx = node.x;
                    node.fy = node.y;
                }
            });
        }

        context.setStatus(mode === "rotate" ? `Rotating ${selectedNodeIds.length} selected vertices.` : `Moving ${selectedNodeIds.length} selected vertices.`);
    }

    function handleNodeDragStart(event: D3DragEvent<SVGCircleElement, unknown, ForceNodeDatum>, _datum: unknown): void {
        const nodeData = event.subject;

        if (!event.active) {
            context.simulation.alphaTarget(0.25).restart();
        }

        const selectedNodeIds = context.getSelectedNodeIds();
        if (selectedNodeIds.length > 1 && context.isNodeSelected(nodeData.id)) {
            const [pointerX, pointerY] = toGraphPoint(context.svg, context.currentTransform, event.sourceEvent as MouseEvent | PointerEvent);
            beginSelectionDrag(event.sourceEvent.altKey ? "rotate" : "move", pointerX, pointerY);
            return;
        }

        nodeData.fx = nodeData.x;
        nodeData.fy = nodeData.y;
        context.setStatus(`Dragging node ${nodeData.id}.`);
    }

    function handleNodeDragged(event: D3DragEvent<SVGCircleElement, unknown, ForceNodeDatum>, _datum: unknown): void {
        const nodeData = event.subject;

        if (selectionDragState) {
            const [pointerX, pointerY] = toGraphPoint(context.svg, context.currentTransform, event.sourceEvent as MouseEvent | PointerEvent);
            updateSelectionDrag(pointerX, pointerY);
            return;
        }

        const [x, y] = toGraphPoint(context.svg, context.currentTransform, event.sourceEvent as MouseEvent | PointerEvent);
        nodeData.fx = x;
        nodeData.fy = y;
        nodeData.anchorX = x;
        nodeData.anchorY = y;
        context.positionGraphElements();
    }

    function handleNodeDragEnd(event: D3DragEvent<SVGCircleElement, unknown, ForceNodeDatum>, _datum: unknown): void {
        const nodeData = event.subject;

        if (!event.active) {
            context.simulation.alphaTarget(0);
        }

        if (selectionDragState) {
            finishSelectionDrag();
            return;
        }

        if (context.isRepulsionEnabled()) {
            nodeData.fx = undefined;
            nodeData.fy = undefined;
        } else {
            nodeData.anchorX = nodeData.x;
            nodeData.anchorY = nodeData.y;
            nodeData.fx = nodeData.x;
            nodeData.fy = nodeData.y;
        }
        context.setStatus(`Node ${nodeData.id} moved.`);
    }

    function createDragBehavior<TDatum>(subjectAccessor: (event: D3DragEvent<SVGCircleElement, TDatum, ForceNodeDatum>, datum: TDatum) => ForceNodeDatum): d3.DragBehavior<SVGCircleElement, TDatum, ForceNodeDatum> {
        return d3.drag<SVGCircleElement, TDatum, ForceNodeDatum>()
            .filter((event: MouseEvent) => event.button === 0)
            .subject(subjectAccessor)
            .on("start", handleNodeDragStart)
            .on("drag", handleNodeDragged)
            .on("end", handleNodeDragEnd);
    }

    const nodeDrag = createDragBehavior<ForceNodeDatum>((_event, nodeData) => nodeData);
    const tokenDrag = createDragBehavior<GraphToken>((_event, tokenData) => {
        const node = context.getNodeById(tokenData.nodeId);
        if (!node) {
            throw new Error(`Token ${tokenData.id} points to a missing node.`);
        }

        return node;
    });

    function handleWindowMouseMove(event: MouseEvent): void {
        const pointer = toGraphPoint(context.svg, context.currentTransform, event);

        if (edgeDragState) {
            edgeDragState.x2 = pointer[0];
            edgeDragState.y2 = pointer[1];
            context.edgePreview
                .attr("x2", pointer[0])
                .attr("y2", pointer[1]);
            return;
        }

        if (selectionBoxState) {
            selectionBoxState.x2 = pointer[0];
            selectionBoxState.y2 = pointer[1];
            renderSelectionBox();
        }
    }

    function handleWindowMouseUp(event: MouseEvent): void {
        if (edgeDragState && event.button === 2) {
            event.preventDefault();
            const [x, y] = toGraphPoint(context.svg, context.currentTransform, event);
            const sourceNodeId = edgeDragState.source.id;
            const targetNode = context.getNodeAtPoint(x, y, sourceNodeId);

            if (targetNode) {
                if (context.removeEdge(sourceNodeId, targetNode.id)) {
                    context.refreshGraphAfterMutation(`Edge between nodes ${sourceNodeId} and ${targetNode.id} removed.`);
                } else if (context.addEdge(sourceNodeId, targetNode.id)) {
                    context.refreshGraphAfterMutation(`Edge added between nodes ${sourceNodeId} and ${targetNode.id}.`);
                } else {
                    context.setStatus(`Edge between nodes ${sourceNodeId} and ${targetNode.id} would violate p-fairness, so it was blocked.`);
                }
                stopEdgeDrag();
                return;
            }

            const newNodeData = context.addNodeAtPoint(x, y);
            if (context.addEdge(sourceNodeId, newNodeData.id)) {
                context.refreshGraphAfterMutation(`Node ${newNodeData.id} added and connected to node ${sourceNodeId}.`);
            }

            stopEdgeDrag();
            return;
        }

        if (selectionBoxState && event.button === 2) {
            event.preventDefault();
            const [x, y] = toGraphPoint(context.svg, context.currentTransform, event);
            selectionBoxState.x2 = x;
            selectionBoxState.y2 = y;
            renderSelectionBox();

            context.selectNodesInRectangle(selectionBoxState.x1, selectionBoxState.y1, selectionBoxState.x2, selectionBoxState.y2);
            stopSelectionBox();
        }
    }

    function handleNodeMouseDown(event: MouseEvent, nodeData: GraphNode): void {
        if (event.button === 1) {
            event.preventDefault();
            event.stopPropagation();
            if (context.removeNode(nodeData.id)) {
                context.refreshGraphAfterMutation(`Node ${nodeData.id} removed.`);
            }
            return;
        }

        if (event.button === 2) {
            event.preventDefault();
            event.stopPropagation();
            startEdgeDrag(nodeData as ForceNodeDatum);
        }
    }

    function handleBackgroundMouseDown(event: MouseEvent): void {
        if (event.button === 1) {
            event.preventDefault();
            event.stopPropagation();
            const [x, y] = toGraphPoint(context.svg, context.currentTransform, event);
            const nodeData = context.addNodeAtPoint(x, y);
            context.refreshGraphAfterMutation(`Node ${nodeData.id} added.`);
            return;
        }

        if (event.button === 2) {
            event.preventDefault();
            event.stopPropagation();
            const [x, y] = toGraphPoint(context.svg, context.currentTransform, event);
            startSelectionBox(x, y);
        }
    }

    function destroy(): void {
        stopEdgeDrag();
        stopSelectionBox();
        selectionDragState = null;
    }

    return {
        nodeDrag,
        tokenDrag,
        handleNodeMouseDown,
        handleBackgroundMouseDown,
        stopEdgeDrag,
        destroy,
    };
}